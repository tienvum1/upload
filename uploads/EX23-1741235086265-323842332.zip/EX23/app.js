var express = require("express");
var path = require("path");
var cookieParser = require("cookie-parser");
const session = require("express-session");
var logger = require("morgan");
var indexRouter = require("./routes/index");
var usersRouter = require("./routes/users.js");
var articleRouter = require("./routes/articleRouter");
var commentRouter = require("./routes/commentRouter");

const url = "mongodb://localhost:27017/Ex16";
const passport = require("./config/jwtConfig");

const mongoose = require("mongoose");
var app = express();
// cấu hình session
app.use(
  session({
    secret: "123kmd123",
    resave: false, // Không lưu session nếu không thay đổi
    saveUninitialized: false, // Không tạo session nếu không có dữ liệu
    cookie: { maxAge: 24 * 60 * 60 * 1000 },
  })
);

// Middleware
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.use("/", indexRouter);
app.use("/users", usersRouter);
app.use("/articles", passport.verifyUser, articleRouter);
app.use(
  "/comments",
  passport.authenticate("jwt", { session: false }),
  commentRouter
);

mongoose.set("strictQuery", true);
mongoose
  .connect(url)
  .then(() => console.log("MongoDB connected successfully!"))
  .catch((err) => console.error(" MongoDB connection error:", err));

const PORT = 8088;
app.listen(PORT, () =>
  console.log(`🚀 Server is running on port http://localhost:${PORT}`)
);
