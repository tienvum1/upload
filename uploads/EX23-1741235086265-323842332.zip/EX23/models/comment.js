const mongoose = require("mongoose");
const { Schema } = mongoose;

const commentSchema = new Schema({
  body: {
    type: String,
    required: [true, "Comment body is required."],
  },
  date: {
    type: Date,
    default: Date.now,
  },
  article: { type: Schema.Types.ObjectId, ref: "Article", required: true },
});

const Comment = mongoose.model("Comment", commentSchema, "comments");
module.exports = Comment;
