const mongoose = require("mongoose");
const { Schema } = mongoose;

const articleSchema = new Schema({
  title: {
    type: String,
    required: [true, "Article title is required."],
    minlength: [5, "Title must be at least 5 characters."],
    trim: true,
  },
  date: {
    type: Date,
    default: Date.now,
  },
  text: {
    type: String,
    required: [true, "Article text is required."],
  },
  comments: [{ type: Schema.Types.ObjectId, ref: "Comment" }], // Thêm reference tới Comment
  tags: {
    type: [String],
    validate: {
      validator: function (v) {
        return v && v.length > 0;
      },
      message: "There should be at least 1 tag.",
    },
  },
});

const Article = mongoose.model("Article", articleSchema, "articles");
module.exports = Article;
