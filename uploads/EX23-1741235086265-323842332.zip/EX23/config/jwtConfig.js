const passport = require("passport");
const JwtStrategy = require("passport-jwt").Strategy;
const ExtractJwt = require("passport-jwt").ExtractJwt;
const jwt = require("jsonwebtoken"); // tạo và xác thực token
const dotenv = require("dotenv");
const User = require("../models/user");

dotenv.config();

// Cấu hình tùy chọn cho JWT Strategy
const opts = {
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(), // lấy token từ header "Authorization: Bearer <token>"
  secretOrKey: process.env.JWT_SECRET,
};

// Cấu hình chiến lược JWT
passport.use(
  new JwtStrategy(opts, async (jwt_payload, done) => {
    try {
      console.log("JWT Payload:", jwt_payload);
      const user = await User.findById(jwt_payload._id);
      return user ? done(null, user) : done(null, false);
    } catch (error) {
      return done(error, false);
    }
  })
);

// Nếu bạn vẫn muốn có verifyUser riêng, bạn có thể gắn nó vào đối tượng passport:
passport.verifyUser = function (req, res, next) {
  var token =
    req.body.token || req.query.token || req.headers["x-access-token"];
  if (token) {
    jwt.verify(token, process.env.JWT_SECRET, function (err, decoded) {
      if (err) {
        var err = new Error("You are not authenticated!");
        err.status = 401;
        return next(err);
      } else {
        req.user = decoded;
        next();
      }
    });
  } else {
    var err = new Error("No token provided!");
    err.status = 403;
    return next(err);
  }
};

// Xuất toàn bộ đối tượng passport
module.exports = passport;
