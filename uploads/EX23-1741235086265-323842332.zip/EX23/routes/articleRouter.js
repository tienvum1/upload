const express = require("express");
const articleController = require("../controllers/articleController");
const articleRouter = express.Router();
articleRouter.use(express.json());
articleRouter.use(express.urlencoded({ extended: true }));
articleRouter
  .route("/")
  .get(articleController.getArticles)
  .post(articleController.createArticle)
  .put((req, res) => {
    res.status(403).json("PUT operation not supported on /articles");
  })
  .delete(articleController.deleteAllArticles);
articleRouter
  .route("/:id")
  .get(articleController.getArticleById)
  .post((req, res) => {
    res
      .status(403)
      .end("POST operation not supported on /articles/" + req.params.id);
  })
  .put(articleController.updateArticleById)
  .delete(articleController.deleteArticleById);
module.exports = articleRouter;
