var express = require("express");
var router = express.Router();
const Comment = require("../models/comment");
const Article = require("../models/article");

// API: Lấy danh sách bình luận kèm theo bài viết
router.get("/list", async (req, res) => {
  try {
    const comments = await Comment.find().populate("article");

    res.json(comments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// API: Thêm bình luận vào bài viết
router.post("/add", async (req, res) => {
  try {
    const { body, articleId } = req.body;

    const article = await Article.findById(articleId);
    if (!article) {
      return res.status(404).json({ error: "Article not found!" });
    }

    const newComment = new Comment({ body, article: articleId });
    const savedComment = await newComment.save();

    article.comments.push(savedComment._id);
    await article.save();

    res.status(201).json({
      message: " Comment added successfully!",
      comment: savedComment,
    });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
