const Article = require("../models/article");

exports.getArticles = async (req, res) => {
  try {
    const articles = await Article.find().populate("comments");
    res.json(articles);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getArticleById = async (req, res) => {
  try {
    const { id } = req.params;
    const article = await Article.findById(id).populate("comments");
    if (!article) {
      return res.status(404).json({ message: "Article not found." });
    }
    res.json(article);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.createArticle = async (req, res) => {
  try {
    const { title, text, tags } = req.body;
    const newArticle = new Article({ title, text, tags });
    const savedArticle = await newArticle.save();
    res.status(201).json({
      message: "✅ Article created successfully!",
      article: savedArticle,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateArticleById = async (req, res) => {
  try {
    const updatedArticle = await Article.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(updatedArticle);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.deleteArticleById = async (req, res) => {
  try {
    const deletedArticle = await Article.findByIdAndDelete(req.params.id);
    res.json(deletedArticle);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};
exports.deleteAllArticles = async (req, res) => {
  try {
    const result = await Article.deleteMany({});
    res.json({
      message: "🗑️ All articles have been deleted.",
      deletedCount: result.deletedCount,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

